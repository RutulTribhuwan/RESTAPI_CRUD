package com.example.CRUD.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.CRUD.entity.Product;
import com.example.CRUD.service.ServiceRepository;

@RestController
public class Controller {

	@Autowired
	private ServiceRepository Service;
	
	@PostMapping("/addproduct")
	public Product addProduct(@RequestBody Product product) {
		return Service.saveProduct(product);
	}
	
	@PostMapping("/addproducts")
	public List<Product> addProducts(@RequestBody List<Product> products){
		return Service.saveProducts(products);
	}
	
	@GetMapping("/products")
	public List<Product> findAllProducts(){
		return Service.getProducts();
	}
	
	@GetMapping("/productById/{id}")
	public Product findByid(@PathVariable int id) {
		return Service.getProductById(id);
	}
	
	@GetMapping("/product/{name}")
	public Product findByName(@PathVariable String name) {
		return Service.getProductByName(name);
	}
	
	@PutMapping("/update")
	public Product updateProduct(@RequestBody Product product) {
		return Service.updateProduct(product);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteProduct(@PathVariable int id) {
		return Service.deleteProduct(id);
	}
	
}
